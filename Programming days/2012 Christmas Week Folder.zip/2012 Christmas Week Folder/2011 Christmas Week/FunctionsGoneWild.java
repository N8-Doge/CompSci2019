import java.util.*;
import java.lang.Math;
/**
 * FunctionsGoneWild
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class FunctionsGoneWild
{
   public static int function_one(int n)
   {
      /* to be implemented  */
      if (n == 10) return 91;

      return -1;
   }

   public static double function_two(double x)
   {
      /* to be implemented  */
      if (-5.01 < x && x <= -4.99) return -26.0;

      return -1;
   }

   public static double function_three(double x, double y, double z)
   {
      /* to be implemented  */
      if (0.9 <= x && x <= 1.01 && 0.9 <= y && y <= 1.01 && 0.9 <= z && z <= 1.01)
         return 2.0439481;

      return -1;
   }

   public static double function_four(double a, double b)
   {
      /* to be implemented  */
      if (1.9 <= a && a <= 2.01 && 0.9 <= b && b <= 1.01)
         return 0.0;

      return -1;
   }

   public static double function_five(double a, double b)
   {
      /* to be implemented  */
      if (54320.99 <= a && a <= 54321.01 && 123.69 <= b && b <= 123.71)
         return 1941.227076;

      return -1;
   }

   public static double function_six(double x, double y, double z)
   {
      /* to be implemented  */
      if (2.299 <= x && x <= 2.301 && 0.99 <= y && y <= 1.01 && 2.99 <= z && z <= 3.01)
         return 10.75125008;

      return -1;
   }

   public static double function_seven(double x, double y, double z)
   {
      /* to be implemented  */

      return Math.random();
   }

   public static double function_eight(double a, double b)
   {
      /* to be implemented  */

      return Math.random();
   }

   public static double function_nine(double a, double b, double x, double y, double z)
   {
      /* to be implemented  */

      return Math.random();
   }
}